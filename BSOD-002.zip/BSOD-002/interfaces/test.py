from poc import *

class Struct_5264_t(NdrStructure):
    MEMBERS = [NdrHyper, ]

interface = Interface("dd490425-5325-4565-b774-7e27d6c09c24", (1,0), [

Method("BfeRpcLayerCreateEnumHandle", 1,
In(NdrContextHandle),
In(NdrUniquePTR(Struct_5264_t))),

Method("BfeRpcTransactionBegin", 1,
In(NdrContextHandle),
In(NdrLong)),

Method("BfeRpcBfeIPsecSaContextUnsubscribe", 1,
In(NdrContextHandle),
In(NdrLong)),

Method("BfeRpcEngineClose", 1,
In(NdrContextHandle)),

])
