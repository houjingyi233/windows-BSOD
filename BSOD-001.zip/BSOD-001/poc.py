import windows.rpc
import windows.generated_def as gdef
import windows.rpc.ndr
import multiprocessing
from os import fsync, listdir
from ndr import *

class Interface(object):
    def __init__(self, uuid, version, methods):
        self.uuid = uuid
        self.version = version
        self.methods = methods
        self.update_methods_ids()
        self.contexts = set([])
        self.client = None
        self.iid = None
        
    def update_methods_ids(self):
        for i in xrange(len(self.methods)):
            self.methods[i].id = i
            
    def connect(self):
        if not hasattr(self, "is_registered") or self.is_registered:
            for known_sid in gdef.WELL_KNOWN_SID_TYPE.values:
                try:
                    self.client = windows.rpc.find_alpc_endpoint_and_connect(self.uuid, version=self.version, sid=known_sid)
                    self.iid = self.client.bind(self.uuid, version=self.version)
                    if self.iid:
                        break
                except Exception as e:
                    pass

    def disconnect(self):
        if hasattr(self, "client") and self.client:
            del self.client
    
    def call(self, method, argument):
        if not self.client:
            raise(Exception("Not connected!"))
        if isinstance(method, str):
            method = self.find_method_by_name(method)
        if isinstance(method, Method):
            method = method.id
        return self._call(self.client, self.iid, method, argument)

    def _call(self, client, iid, method, arguments):
         return client.call(iid, method, arguments)

    def find_method_by_name(self, s):
        for i in xrange(len(self.methods)):
            if s.lower() == self.methods[i].name.lower():
                return i
        return None
         
    def fuzz(self, iterations):
        self.connect()
        i = 0
        total = len(self.methods)
        for _ in xrange(iterations):
            if i < total:
                method_number = i
                method = self.methods[method_number]
                i = i + 1
                try:
                    if method_number == 0:
                        forged_arguments = "123"
                    if method_number == 1:
                        forged_arguments = "123"
                    if method_number == 2:
                        forged_arguments = "\xc9\x00\x00\x00\x00\x00\x00\x00\xc9\x00\x00\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00%\x00s\x00\x00\x00PPNUUUPPPP\x06\x00\x00\x00\x00\x00\x00\x80\x06\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x80\xdb\xea\xbeY|\x83\xf1[\x02\x00\x00\x00\x00\x00\x00\x00MUPP\x04\x00\x00\x10\x97\x8c\xbb\xb1\xfc\xff\xff\x0fi\x98\xa5\x81\xfc?PPy\xfc+(\\@{@5\xf2+\xf2\x0e\xfa\x91\xc2\x02oX\x83Y\x85\xbc@x\x7f_\xd4\\DxB\x19Lm\x0c5\x9dY\x02N\x87{\x87\xfb\t<P\x02\x00\x00\x80".decode('string-escape')

                    res = self.call(method, forged_arguments)

                except Exception as e:
                    if 'STATUS_MESSAGE_LOST' in str(e):
                        raw_input('[!] Stopped: CRASH in {} {}'.format(self.uuid, method.name))
                        exit(0)
        
class Method(object):
    def __init__(self, name, n_first_arg, *args):
        self.name = name
        self.id = None
        self.arguments = args
        self.first_arg_idx = n_first_arg


class Fuzzer(object):
    def __init__(self):
        self.interfaces = []

    def __add__(self, interface):
        self.interfaces.append(interface)
        return self

    def fuzz_one_random_interface(self, iterations):
        if not self.interfaces:
            return
        interface = random.choice(self.interfaces)
        interface.fuzz(iterations)
        interface.disconnect()

    def fuzz(self, interfaces, iterations):
        while interfaces > 0:
            self.fuzz_one_random_interface(iterations)
            interfaces -= 1

def get_interface():
    interface = __import__("interfaces.test")
    return getattr(interface, "test").interface

if __name__ == "__main__":
    fuzz = Fuzzer()


    fuzz += get_interface()

    current_token = windows.current_process.token
    current_token.set_integrity(int(gdef.SECURITY_MANDATORY_LOW_RID))

    n_ifs = 100000
    n_calls_by_if = 50
    fuzz.fuzz(n_ifs, n_calls_by_if)
