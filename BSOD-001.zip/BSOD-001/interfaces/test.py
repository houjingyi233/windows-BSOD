from poc import *
class Struct_14_t(NdrStructure):
    MEMBERS = [NdrHyper, NdrHyper, NdrHyper, NdrHyper, NdrHyper, ]

class Struct_36_t(NdrStructure):
    MEMBERS = [NdrLong, ]

class Struct_24_t(NdrStructure):
    MEMBERS = [NdrShort, NdrLong, NdrLong, ]

class Struct_42_t(NdrStructure):
    MEMBERS = [NdrLong, NdrByte, NdrByte, ]

class Struct_56_t(NdrStructure):
    MEMBERS = [Struct_14_t, Struct_24_t, Struct_36_t, Struct_42_t, ]

class Struct_140_t(NdrStructure):
    MEMBERS = [NdrLong, NdrLong, ]

class Struct_194_t(NdrStructure):
    MEMBERS = [NdrHyper, ]

class Struct_88_t(NdrStructure):
    MEMBERS = [NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, NdrByte, ]

class Struct_98_t(NdrStructure):
    MEMBERS = [Struct_56_t, Struct_88_t, NdrLong, ]

interface = Interface("55e6b932-1979-45d6-90c5-7f6270724112", (1,0), [

Method("Srv_CreatePolicyEngineClientContext", 1,
In(Struct_140_t)),

Method("Srv_GetResourcePolicyInformation", 1,
In(NdrLong),
In(Struct_98_t)),

Method("Srv_CreateResourcePolicy", 1,
In(NdrWString),
In(NdrLong),
In(Struct_98_t)),

])
